// Constructor accent colours keyed by Jolpica/Ergast constructorId.
// Used for the left rail in archive standings. Unknown -> neutral grey.
const TEAM_COLOUR: Record<string, string> = {
  red_bull: "#3671C6",
  ferrari: "#E8002D",
  mercedes: "#27F4D2",
  mclaren: "#FF8000",
  aston_martin: "#229971",
  alpine: "#0093CC",
  williams: "#64C4FF",
  rb: "#6692FF",
  alphatauri: "#6692FF",
  toro_rosso: "#6692FF",
  sauber: "#52E252",
  haas: "#B6BABD",
  // a few historical mainstays
  renault: "#FFF500",
  lotus_f1: "#FFB800",
  force_india: "#F596C8",
  racing_point: "#F596C8",
  brawn: "#B8FD6E",
  benetton: "#0085CA",
  jordan: "#FFD700",
  tyrrell: "#1E3A8A",
  team_lotus: "#0E5C2F"
};

export function teamColour(constructorId: string | undefined): string {
  if (!constructorId) return "#565C66";
  return TEAM_COLOUR[constructorId] ?? "#565C66";
}
