import type { OpenF1Session } from "@/lib/types";
import { dayMonth } from "@/lib/format";

export function SessionHeader({ session }: { session: OpenF1Session | null }) {
  if (!session) {
    return (
      <div className="p-4 font-mono text-[12px] text-ink-dim">Awaiting session feed…</div>
    );
  }
  const stat = (label: string, value: string) => (
    <div className="flex flex-col gap-0.5">
      <span className="eyebrow">{label}</span>
      <span className="font-mono text-[12px] text-ink">{value}</span>
    </div>
  );
  return (
    <div className="flex flex-col gap-4 p-4">
      <div>
        <h2 className="font-display text-2xl font-black leading-none tracking-tight text-ink">
          {session.location.toUpperCase()}
        </h2>
        <p className="mt-1 font-mono text-[11px] uppercase tracking-eyebrow text-ink-dim">
          {session.country_name} · {session.year}
        </p>
      </div>
      <div className="grid grid-cols-2 gap-3 border-t border-grid pt-3">
        {stat("Session", session.session_name)}
        {stat("Type", session.session_type)}
        {stat("Circuit", session.circuit_short_name)}
        {stat("Date", dayMonth(session.date_start))}
      </div>
    </div>
  );
}
