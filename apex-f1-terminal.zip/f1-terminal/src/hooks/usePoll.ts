"use client";

import { useEffect, useRef, useState } from "react";

interface PollState<T> {
  data: T | null;
  error: boolean;
  loading: boolean;
  updatedAt: number | null;
}

/**
 * Calls `fetcher` immediately, then every `intervalMs`. Polling pauses while the
 * tab is hidden (saves upstream quota) and resumes on focus.
 */
export function usePoll<T>(
  fetcher: () => Promise<T>,
  intervalMs: number,
  deps: unknown[] = []
): PollState<T> {
  const [state, setState] = useState<PollState<T>>({
    data: null,
    error: false,
    loading: true,
    updatedAt: null
  });
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  useEffect(() => {
    let alive = true;
    let timer: ReturnType<typeof setTimeout>;

    const tick = async () => {
      try {
        const data = await fetcherRef.current();
        if (alive) setState({ data, error: false, loading: false, updatedAt: Date.now() });
      } catch {
        if (alive) setState((s) => ({ ...s, error: true, loading: false }));
      } finally {
        if (alive && !document.hidden) timer = setTimeout(tick, intervalMs);
      }
    };

    const onVisible = () => {
      if (!document.hidden) tick();
    };

    tick();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      alive = false;
      clearTimeout(timer);
      document.removeEventListener("visibilitychange", onVisible);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intervalMs, ...deps]);

  return state;
}
