# APEX — Formula 1 Terminal

A Bloomberg-style terminal for Formula 1. Live timing, tyres, weather and race
control alongside the full championship archive back to 1950. Next.js 15 App
Router, TypeScript, Tailwind. No database, no auth required to run.

## What's in v1

**LIVE tab** — driven by [OpenF1](https://openf1.org). The signature element is
a broadcast-style timing tower with team-colour rails, live position deltas
(▲ / ▼), tyre compound + age, and the overall fastest last lap rendered in
purple (the F1 broadcast convention). A right rail shows session header, the
tyre legend, a weather strip (track / air / humidity / wind / rain), and a
colour-coded race-control message feed.

**ARCHIVE tab** — driven by [jolpica-f1](https://github.com/jolpica/jolpica-f1),
the Ergast-compatible successor API. Season scrubber from 1950 → present, with
Drivers and Constructors championship standings (with team-colour rails and
inline points bars) and the season calendar.

A persistent status bar shows a live/latest indicator, the current session, the
current flag, feed health and a UTC clock.

## Run it

```bash
pnpm install      # or npm install / yarn
cp .env.example .env
pnpm dev
```

Open `http://localhost:3000`. **Everything works with no credentials.** Jolpica
needs none. OpenF1 only needs credentials to access its *protected live window*
(from 30 min before a session starts to 30 min after it ends). Without them you
still see the most recent session — it just won't stream the in-progress feed
during that protected window. Create an account at openf1.org and fill in
`OPENF1_USERNAME` / `OPENF1_PASSWORD` to enable true live streaming.

## Deploy

This is a standard Next.js app — deploy on Vercel with one click. Set the two
OpenF1 env vars in the project settings if you want the protected live window.

```bash
vercel
```

## Architecture

```
src/
  app/
    layout.tsx                 # Google Fonts wired to CSS vars
    page.tsx                   # tab shell: LIVE | ARCHIVE
    globals.css                # base + terminal texture
    api/
      openf1/[...path]/        # proxy w/ caching + optional OAuth token
      jolpica/[...path]/       # proxy w/ 1h cache for the historical archive
  components/
    StatusBar.tsx              # always-on top bar (clock, flag, live state)
    Panel.tsx                  # bordered terminal panel w/ eyebrow header
    live/
      LiveBoard.tsx            # orchestrates all live polling
      TimingTower.tsx          # the signature element
      SessionHeader.tsx
      WeatherStrip.tsx
      RaceControl.tsx
    archive/
      ArchiveBoard.tsx         # season scrubber + 3-column layout
      StandingsTable.tsx
      ScheduleTable.tsx
  hooks/usePoll.ts             # poll w/ pause-on-hidden
  lib/
    openf1.ts                  # OpenF1 client + tower row merger
    jolpica.ts                 # Jolpica/Ergast client
    types.ts
    format.ts                  # lap time, gap, UTC clock helpers
    teams.ts                   # constructor accent colour map
    tyres.ts                   # Pirelli compound colours
```

### Why proxy the APIs?

Two reasons. **Caching** — OpenF1's free tier is 30 req/min; many visitors all
polling every few seconds would blow that instantly. The proxy uses Next.js
`revalidate` to collapse them into one upstream call per window per endpoint.
**Secrets** — the optional OpenF1 token never touches the browser.

### Poll cadences

Tuned to match how often each feed actually changes upstream:

| Feed | Cadence | Reason |
|---|---|---|
| `position`, `intervals` | 5 s | Match OpenF1's ~3 s update rate |
| `laps` | 6 s | Lap completions are bursty |
| `race_control` | 8 s | Flags need to feel immediate |
| `stints` | 15 s | Compounds change at pit stops |
| `sessions`, `weather` | 30 s | Slow-moving |
| `drivers` | 2 m | Effectively static per session |

Polling pauses while the tab is hidden — courtesy to OpenF1's quota.

## Design notes

The palette is grounded in F1's own timing language rather than the
generic "acid-green on black" terminal default: **F1 red** as the single
spark, **green for personal best**, **purple for overall fastest**, **amber
for yellow-flag**. Those come from a real broadcast timing screen, so they
read as F1 to anyone who's watched a race, not as a stylistic gesture.

**Type:** Titillium Web for display (the open face F1's own wordmark is built
on), JetBrains Mono for every piece of timing data, Inter for body. **The
signature** is the timing tower itself — team-coloured rails, tyre dots,
movement arrows — sitting inside the terminal chrome.

## Things to build next

- Driver detail drawer: lap chart, sector deltas, pit-stop history
- Telemetry replay scrubber (OpenF1 `car_data`: throttle, brake, RPM, gear)
- Constructor detail: every season's finish position + career win count
- Track map with live car positions (OpenF1 `location`)
- Saved layouts (Bloomberg-style multi-monitor "workspaces")

## Data sources

- [OpenF1](https://openf1.org) — live and historical timing, telemetry, weather
- [jolpica-f1](https://github.com/jolpica/jolpica-f1) — Ergast-compatible
  archive (1950 → present)

Both are free and unofficial; this project is not affiliated with Formula 1.
