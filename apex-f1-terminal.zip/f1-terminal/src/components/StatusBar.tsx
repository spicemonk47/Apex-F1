"use client";

import { useEffect, useState } from "react";
import type { OpenF1Session } from "@/lib/types";
import { utcClock } from "@/lib/format";

function isLiveWindow(s: OpenF1Session | null): boolean {
  if (!s) return false;
  const start = new Date(s.date_start).getTime() - 30 * 60_000;
  const end = new Date(s.date_end).getTime() + 30 * 60_000;
  const now = Date.now();
  return now >= start && now <= end;
}

const FLAG_TONE: Record<string, string> = {
  GREEN: "text-gain border-gain/40",
  YELLOW: "text-amber border-amber/40",
  "DOUBLE YELLOW": "text-amber border-amber/40",
  RED: "text-f1 border-f1/50",
  CHEQUERED: "text-ink border-grid",
  CLEAR: "text-gain border-gain/40"
};

export function StatusBar({
  session,
  flag,
  feedOk
}: {
  session: OpenF1Session | null;
  flag: string | null;
  feedOk: boolean;
}) {
  const [clock, setClock] = useState("--:--:-- UTC");
  useEffect(() => {
    const t = setInterval(() => setClock(utcClock(new Date())), 1000);
    setClock(utcClock(new Date()));
    return () => clearInterval(t);
  }, []);

  const live = isLiveWindow(session);
  const flagKey = (flag ?? "").toUpperCase();
  const flagTone = FLAG_TONE[flagKey] ?? "text-ink-dim border-grid";

  return (
    <header className="flex h-11 items-center gap-4 border-b border-grid bg-panel px-3 sm:px-4">
      {/* wordmark */}
      <div className="flex items-baseline gap-2">
        <span className="font-display text-lg font-black leading-none tracking-tight text-ink">
          APEX
        </span>
        <span className="hidden font-mono text-[10px] uppercase tracking-eyebrow text-ink-faint sm:inline">
          F1 Terminal
        </span>
      </div>

      <div className="h-5 w-px bg-grid" />

      {/* live / latest indicator */}
      <div className="flex items-center gap-2">
        <span
          className={`h-2 w-2 rounded-full ${
            live ? "animate-livepulse bg-f1" : "bg-ink-faint"
          }`}
        />
        <span
          className={`font-mono text-[11px] font-bold tracking-wide ${
            live ? "text-f1" : "text-ink-dim"
          }`}
        >
          {live ? "LIVE" : "LATEST"}
        </span>
      </div>

      {/* session / track */}
      <div className="hidden min-w-0 items-center gap-2 md:flex">
        <span className="truncate font-mono text-[11px] text-ink-dim">
          {session
            ? `${session.circuit_short_name.toUpperCase()} · ${session.session_name.toUpperCase()}`
            : "AWAITING FEED"}
        </span>
      </div>

      {/* flag chip */}
      {flagKey && (
        <span
          className={`hidden border px-2 py-0.5 font-mono text-[10px] font-bold uppercase tracking-wide lg:inline ${flagTone}`}
        >
          {flagKey}
        </span>
      )}

      <div className="ml-auto flex items-center gap-3 sm:gap-4">
        <span className="hidden items-center gap-1.5 sm:flex">
          <span className={`h-1.5 w-1.5 rounded-full ${feedOk ? "bg-gain" : "bg-amber"}`} />
          <span className="font-mono text-[10px] uppercase tracking-eyebrow text-ink-faint">
            {feedOk ? "feed ok" : "degraded"}
          </span>
        </span>
        <span className="num text-[12px] text-ink">{clock}</span>
      </div>
    </header>
  );
}
