import type { RaceSchedule } from "@/lib/types";
import { dayMonth } from "@/lib/format";

export function ScheduleTable({
  races,
  loading
}: {
  races: RaceSchedule[];
  loading: boolean;
}) {
  if (loading) {
    return <div className="p-4 font-mono text-[11px] text-ink-faint">Loading…</div>;
  }
  if (races.length === 0) {
    return <div className="p-4 font-mono text-[11px] text-ink-dim">No calendar found.</div>;
  }
  return (
    <ul className="h-full divide-y divide-grid/60 overflow-auto">
      {races.map((r) => (
        <li key={r.round} className="flex items-center gap-3 px-3 py-2">
          <span className="num w-6 shrink-0 text-[12px] font-bold text-ink-faint">
            {r.round.padStart(2, "0")}
          </span>
          <div className="min-w-0 flex-1">
            <span className="block truncate font-display text-[12px] font-bold leading-tight text-ink">
              {r.raceName.replace(/ Grand Prix$/, "")}
            </span>
            <span className="block truncate font-mono text-[10px] text-ink-faint">
              {r.Circuit.Location.locality}, {r.Circuit.Location.country}
              {r.Sprint ? " · SPRINT" : ""}
            </span>
          </div>
          <span className="num shrink-0 text-[11px] text-ink-dim">{dayMonth(r.date)}</span>
        </li>
      ))}
    </ul>
  );
}
