import type {
  OpenF1Session,
  OpenF1Driver,
  OpenF1Position,
  OpenF1Interval,
  OpenF1Lap,
  OpenF1Stint,
  OpenF1Weather,
  OpenF1RaceControl,
  TowerRow
} from "./types";
import { ensureHash } from "./format";

// All OpenF1 calls go through our own /api/openf1 proxy. The proxy adds caching
// and (if configured) the OAuth token for the protected live window, so the
// browser never needs credentials or hits OpenF1's rate limit directly.
async function of1<T>(endpoint: string, query: Record<string, string>): Promise<T> {
  const qs = new URLSearchParams(query).toString();
  const res = await fetch(`/api/openf1/${endpoint}?${qs}`, { cache: "no-store" });
  if (!res.ok) throw new Error(`OpenF1 ${endpoint} -> ${res.status}`);
  return (await res.json()) as T;
}

export const getLatestSession = () =>
  of1<OpenF1Session[]>("sessions", { session_key: "latest" }).then((r) => r[0] ?? null);

export const getDrivers = () => of1<OpenF1Driver[]>("drivers", { session_key: "latest" });
export const getPositions = () => of1<OpenF1Position[]>("position", { session_key: "latest" });
export const getIntervals = () => of1<OpenF1Interval[]>("intervals", { session_key: "latest" });
export const getLaps = () => of1<OpenF1Lap[]>("laps", { session_key: "latest" });
export const getStints = () => of1<OpenF1Stint[]>("stints", { session_key: "latest" });
export const getWeather = () =>
  of1<OpenF1Weather[]>("weather", { session_key: "latest" }).then(
    (r) => r[r.length - 1] ?? null
  );
export const getRaceControl = () =>
  of1<OpenF1RaceControl[]>("race_control", { session_key: "latest" });

// Keep only the most recent sample per driver from a time-series array.
function latestPerDriver<T extends { driver_number: number; date?: string }>(rows: T[]): Map<number, T> {
  const out = new Map<number, T>();
  for (const row of rows) {
    const prev = out.get(row.driver_number);
    if (!prev || (row.date ?? "") >= (prev.date ?? "")) out.set(row.driver_number, row);
  }
  return out;
}

/** Merge the five live feeds into one sorted timing tower. */
export function buildTower(
  drivers: OpenF1Driver[],
  positions: OpenF1Position[],
  intervals: OpenF1Interval[],
  laps: OpenF1Lap[],
  stints: OpenF1Stint[]
): TowerRow[] {
  const posByDriver = latestPerDriver(positions);
  const intByDriver = latestPerDriver(intervals);

  // last completed lap = highest lap_number per driver
  const lastLap = new Map<number, number | null>();
  for (const l of laps) {
    const cur = lastLap.has(l.driver_number);
    if (!cur || (l.lap_number ?? 0) >= 0) {
      const prev = laps
        .filter((x) => x.driver_number === l.driver_number)
        .reduce((a, b) => ((b.lap_number ?? 0) > (a.lap_number ?? 0) ? b : a), l);
      lastLap.set(l.driver_number, prev.lap_duration);
    }
  }

  // current stint = highest stint_number per driver
  const curStint = new Map<number, OpenF1Stint>();
  for (const s of stints) {
    const prev = curStint.get(s.driver_number);
    if (!prev || (s.stint_number ?? 0) >= (prev.stint_number ?? 0)) curStint.set(s.driver_number, s);
  }

  const rows: TowerRow[] = drivers.map((d) => {
    const pos = posByDriver.get(d.driver_number)?.position ?? null;
    const intv = intByDriver.get(d.driver_number);
    const stint = curStint.get(d.driver_number);
    return {
      driver_number: d.driver_number,
      position: pos,
      acronym: d.name_acronym || String(d.driver_number),
      full_name: d.full_name,
      team_name: d.team_name,
      team_colour: ensureHash(d.team_colour),
      gap_to_leader: intv?.gap_to_leader ?? null,
      interval: intv?.interval ?? null,
      last_lap: lastLap.get(d.driver_number) ?? null,
      compound: stint?.compound ?? null,
      tyre_age: stint?.tyre_age_at_start ?? null,
      headshot_url: d.headshot_url
    };
  });

  rows.sort((a, b) => {
    if (a.position == null) return 1;
    if (b.position == null) return -1;
    return a.position - b.position;
  });
  return rows;
}
