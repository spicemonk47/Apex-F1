import type { OpenF1RaceControl } from "@/lib/types";

function tone(m: OpenF1RaceControl): string {
  const f = (m.flag ?? "").toUpperCase();
  if (f === "RED") return "text-f1";
  if (f.includes("YELLOW")) return "text-amber";
  if (f === "GREEN" || f === "CLEAR") return "text-gain";
  if (m.category === "SafetyCar") return "text-amber";
  return "text-ink-dim";
}

export function RaceControl({ messages }: { messages: OpenF1RaceControl[] }) {
  const recent = [...messages].slice(-30).reverse();

  if (recent.length === 0) {
    return (
      <div className="p-4 font-mono text-[11px] text-ink-faint">
        No race-control messages yet.
      </div>
    );
  }

  return (
    <ul className="h-full divide-y divide-grid/60 overflow-auto">
      {recent.map((m, i) => (
        <li key={i} className="flex gap-2 px-3 py-1.5">
          <span className="num shrink-0 text-[10px] text-ink-faint">
            {m.lap_number != null ? `L${String(m.lap_number).padStart(2, "0")}` : "—"}
          </span>
          <span className={`font-mono text-[11px] leading-snug ${tone(m)}`}>{m.message}</span>
        </li>
      ))}
    </ul>
  );
}
