/** 83.214 -> "1:23.214"; 58.91 -> "58.910". null -> "—". */
export function lapTime(seconds: number | null | undefined): string {
  if (seconds == null || !isFinite(seconds)) return "—";
  const m = Math.floor(seconds / 60);
  const s = seconds - m * 60;
  if (m > 0) return `${m}:${s.toFixed(3).padStart(6, "0")}`;
  return s.toFixed(3);
}

/** Gap/interval: number -> "+1.234", strings ("+1 LAP") pass through. */
export function gap(value: number | string | null | undefined): string {
  if (value == null) return "—";
  if (typeof value === "string") return value;
  if (!isFinite(value)) return "—";
  if (value === 0) return "LEADER";
  return `+${value.toFixed(3)}`;
}

export function shortInterval(value: number | string | null | undefined): string {
  if (value == null) return "—";
  if (typeof value === "string") return value;
  if (!isFinite(value)) return "—";
  return `+${value.toFixed(3)}`;
}

/** ISO -> "21 JUN" */
export function dayMonth(iso: string | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso.length <= 10 ? `${iso}T00:00:00Z` : iso);
  if (isNaN(d.getTime())) return "—";
  return d
    .toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: "UTC" })
    .toUpperCase();
}

/** Live UTC clock string, e.g. "14:07:32 UTC". */
export function utcClock(now: Date): string {
  return (
    now.toLocaleTimeString("en-GB", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
      timeZone: "UTC"
    }) + " UTC"
  );
}

export function ensureHash(colour: string | null | undefined): string {
  if (!colour) return "#8A909B";
  return colour.startsWith("#") ? colour : `#${colour}`;
}
