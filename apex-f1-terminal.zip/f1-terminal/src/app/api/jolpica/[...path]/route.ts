import { NextRequest, NextResponse } from "next/server";

const BASE = "https://api.jolpi.ca/ergast/f1";

export async function GET(
  req: NextRequest,
  ctx: { params: Promise<{ path: string[] }> }
) {
  const { path } = await ctx.params;
  const joined = path.join("/");
  const search = req.nextUrl.search || "?limit=100";
  const url = `${BASE}/${joined}${search}`;

  // The historical record is effectively immutable; the current season updates
  // ~weekly. One hour of caching keeps us well under Jolpica's 500 req/hr limit.
  try {
    const upstream = await fetch(url, { next: { revalidate: 3600 } });
    if (!upstream.ok) {
      return NextResponse.json(
        { MRData: {} },
        { status: 200, headers: { "x-jolpica-status": String(upstream.status) } }
      );
    }
    const data = await upstream.json();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ MRData: {} }, { status: 200, headers: { "x-jolpica-status": "error" } });
  }
}
