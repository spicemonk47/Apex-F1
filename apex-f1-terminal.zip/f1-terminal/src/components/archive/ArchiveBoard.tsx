"use client";

import { useEffect, useState } from "react";
import {
  getDriverStandings,
  getConstructorStandings,
  getSchedule,
  SEASONS
} from "@/lib/jolpica";
import type { DriverStanding, ConstructorStanding, RaceSchedule } from "@/lib/types";
import { Panel } from "@/components/Panel";
import { StandingsTable, type StandingRow } from "./StandingsTable";
import { ScheduleTable } from "./ScheduleTable";
import { teamColour } from "@/lib/teams";

export function ArchiveBoard() {
  const [season, setSeason] = useState<number>(SEASONS[0]);
  const [drivers, setDrivers] = useState<DriverStanding[]>([]);
  const [teams, setTeams] = useState<ConstructorStanding[]>([]);
  const [schedule, setSchedule] = useState<RaceSchedule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    Promise.all([
      getDriverStandings(season).catch(() => []),
      getConstructorStandings(season).catch(() => []),
      getSchedule(season).catch(() => [])
    ]).then(([d, c, s]) => {
      if (!alive) return;
      setDrivers(d);
      setTeams(c);
      setSchedule(s);
      setLoading(false);
    });
    return () => {
      alive = false;
    };
  }, [season]);

  const driverRows: StandingRow[] = drivers.map((d) => ({
    pos: d.position,
    name: `${d.Driver.givenName} ${d.Driver.familyName}`,
    sub: d.Constructors[0]?.name ?? "—",
    points: d.points,
    wins: d.wins,
    accent: teamColour(d.Constructors[0]?.constructorId)
  }));

  const teamRows: StandingRow[] = teams.map((t) => ({
    pos: t.position,
    name: t.Constructor.name,
    sub: t.Constructor.nationality,
    points: t.points,
    wins: t.wins,
    accent: teamColour(t.Constructor.constructorId)
  }));

  return (
    <div className="flex h-full min-h-0 flex-col gap-2 p-2">
      {/* season scrubber */}
      <div className="flex items-center gap-3 border border-grid bg-panel px-3 py-2">
        <span className="eyebrow">Season</span>
        <label className="flex items-center gap-2">
          <select
            value={season}
            onChange={(e) => setSeason(Number(e.target.value))}
            className="num border border-grid bg-panel-2 px-2 py-1 text-[13px] font-bold text-ink focus:border-info"
            aria-label="Select season"
          >
            {SEASONS.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </label>
        <span className="ml-auto font-mono text-[10px] text-ink-faint">
          via jolpica-f1 · ergast-compatible
        </span>
      </div>

      {/* 3-column board on lg, stacked otherwise */}
      <div className="grid min-h-0 flex-1 gap-2 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)_22rem]">
        <Panel
          label="Drivers Championship"
          right={`${driverRows.length} entries`}
          bodyClassName="overflow-hidden"
        >
          <StandingsTable rows={driverRows} loading={loading} />
        </Panel>

        <Panel
          label="Constructors Championship"
          right={`${teamRows.length} teams`}
          bodyClassName="overflow-hidden"
        >
          <StandingsTable rows={teamRows} loading={loading} />
        </Panel>

        <Panel
          label="Calendar"
          right={`${schedule.length} rounds`}
          bodyClassName="overflow-hidden"
        >
          <ScheduleTable races={schedule} loading={loading} />
        </Panel>
      </div>
    </div>
  );
}
