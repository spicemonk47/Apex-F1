import type { OpenF1Weather } from "@/lib/types";

export function WeatherStrip({ w }: { w: OpenF1Weather | null }) {
  const cell = (label: string, value: string, tone = "text-ink") => (
    <div className="flex flex-col items-center gap-0.5 px-1 py-2">
      <span className="eyebrow">{label}</span>
      <span className={`num text-[13px] ${tone}`}>{value}</span>
    </div>
  );
  const n = (v: number | null | undefined, suffix: string) =>
    v == null ? "—" : `${v.toFixed(1)}${suffix}`;

  const raining = (w?.rainfall ?? 0) > 0;

  return (
    <div className="grid grid-cols-5 divide-x divide-grid">
      {cell("Track", n(w?.track_temperature, "°"))}
      {cell("Air", n(w?.air_temperature, "°"))}
      {cell("Humid", n(w?.humidity, "%"))}
      {cell("Wind", n(w?.wind_speed, ""))}
      {cell("Rain", raining ? "YES" : "DRY", raining ? "text-info" : "text-ink-dim")}
    </div>
  );
}
