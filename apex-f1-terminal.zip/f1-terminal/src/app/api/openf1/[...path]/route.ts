import { NextRequest, NextResponse } from "next/server";

const BASE = "https://api.openf1.org/v1";

// How long to cache each endpoint upstream (seconds). This decouples the
// browser's poll rate from OpenF1's 30 req/min free-tier limit — many visitors
// polling every few seconds collapse into one upstream hit per window.
const REVALIDATE: Record<string, number> = {
  sessions: 30,
  drivers: 120,
  position: 4,
  intervals: 4,
  laps: 6,
  stints: 15,
  weather: 30,
  race_control: 8
};

// ── optional OAuth token for the protected live window ──────────────────────
let cachedToken: { value: string; expires: number } | null = null;

async function getToken(): Promise<string | null> {
  const username = process.env.OPENF1_USERNAME;
  const password = process.env.OPENF1_PASSWORD;
  if (!username || !password) return null;

  if (cachedToken && cachedToken.expires > Date.now() + 30_000) return cachedToken.value;

  try {
    const res = await fetch(`https://api.openf1.org/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ username, password }),
      cache: "no-store"
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { access_token: string; expires_in: number };
    cachedToken = {
      value: data.access_token,
      expires: Date.now() + (data.expires_in ?? 3600) * 1000
    };
    return cachedToken.value;
  } catch {
    return null;
  }
}

export async function GET(
  req: NextRequest,
  ctx: { params: Promise<{ path: string[] }> }
) {
  const { path } = await ctx.params;
  const endpoint = path[0] ?? "";
  const search = req.nextUrl.search;
  const url = `${BASE}/${path.join("/")}${search}`;

  const headers: HeadersInit = {};
  const token = await getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;

  try {
    const upstream = await fetch(url, {
      headers,
      next: { revalidate: REVALIDATE[endpoint] ?? 10 }
    });

    // OpenF1 returns 422/401 for the protected live window when unauthenticated,
    // or 429 when rate-limited. Surface an empty array so the UI degrades to the
    // "no live feed" state instead of throwing.
    if (!upstream.ok) {
      return NextResponse.json([], { status: 200, headers: { "x-openf1-status": String(upstream.status) } });
    }
    const data = await upstream.json();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json([], { status: 200, headers: { "x-openf1-status": "error" } });
  }
}
