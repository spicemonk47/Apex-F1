"use client";

import { useMemo, useEffect } from "react";
import { usePoll } from "@/hooks/usePoll";
import {
  getLatestSession,
  getDrivers,
  getPositions,
  getIntervals,
  getLaps,
  getStints,
  getWeather,
  getRaceControl,
  buildTower
} from "@/lib/openf1";
import type { OpenF1Session } from "@/lib/types";
import { Panel } from "@/components/Panel";
import { TimingTower } from "./TimingTower";
import { SessionHeader } from "./SessionHeader";
import { WeatherStrip } from "./WeatherStrip";
import { RaceControl } from "./RaceControl";
import { TYRE_LEGEND } from "@/lib/tyres";

export function LiveBoard({
  onSession,
  onFlag,
  onFeed
}: {
  onSession: (s: OpenF1Session | null) => void;
  onFlag: (f: string | null) => void;
  onFeed: (ok: boolean) => void;
}) {
  const session = usePoll(getLatestSession, 30_000);
  const drivers = usePoll(getDrivers, 120_000);
  const positions = usePoll(getPositions, 5_000);
  const intervals = usePoll(getIntervals, 5_000);
  const laps = usePoll(getLaps, 6_000);
  const stints = usePoll(getStints, 15_000);
  const weather = usePoll(getWeather, 30_000);
  const raceControl = usePoll(getRaceControl, 8_000);

  const rows = useMemo(
    () =>
      buildTower(
        drivers.data ?? [],
        positions.data ?? [],
        intervals.data ?? [],
        laps.data ?? [],
        stints.data ?? []
      ),
    [drivers.data, positions.data, intervals.data, laps.data, stints.data]
  );

  const lastFlag = useMemo(() => {
    const msgs = raceControl.data ?? [];
    for (let i = msgs.length - 1; i >= 0; i--) if (msgs[i].flag) return msgs[i].flag;
    return null;
  }, [raceControl.data]);

  const feedOk = !!drivers.data && drivers.data.length > 0;

  // lift state up to the status bar
  useEffect(() => onSession(session.data), [session.data, onSession]);
  useEffect(() => onFlag(lastFlag), [lastFlag, onFlag]);
  useEffect(() => onFeed(feedOk), [feedOk, onFeed]);

  return (
    <div className="grid h-full min-h-0 grid-rows-[minmax(0,1fr)_auto] gap-2 p-2 lg:grid-cols-[minmax(0,1fr)_22rem] lg:grid-rows-1">
      {/* signature: timing tower */}
      <Panel
        label="Live Timing"
        right={`${rows.length} cars`}
        className="min-h-[60vh] lg:min-h-0"
        bodyClassName="overflow-hidden"
      >
        <TimingTower rows={rows} />
      </Panel>

      {/* right column */}
      <div className="grid min-h-0 grid-rows-[auto_auto_minmax(0,1fr)] gap-2">
        <Panel label="Session">
          <SessionHeader session={session.data} />
          <div className="flex flex-wrap items-center gap-2 border-t border-grid px-3 py-2">
            {TYRE_LEGEND.map((t) => (
              <span key={t.name} className="flex items-center gap-1">
                <span
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ backgroundColor: t.colour }}
                />
                <span className="font-mono text-[9px] uppercase tracking-wide text-ink-faint">
                  {t.label}
                </span>
              </span>
            ))}
          </div>
        </Panel>

        <Panel label="Conditions">
          <WeatherStrip w={weather.data} />
        </Panel>

        <Panel label="Race Control" className="min-h-[14rem]" bodyClassName="overflow-hidden">
          <RaceControl messages={raceControl.data ?? []} />
        </Panel>
      </div>
    </div>
  );
}
