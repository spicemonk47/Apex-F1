export interface StandingRow {
  pos: string;
  name: string;
  sub: string;
  points: string;
  wins: string;
  accent: string;
}

export function StandingsTable({
  rows,
  loading
}: {
  rows: StandingRow[];
  loading: boolean;
}) {
  if (loading) {
    return <div className="p-4 font-mono text-[11px] text-ink-faint">Loading…</div>;
  }
  if (rows.length === 0) {
    return (
      <div className="p-4 font-mono text-[11px] leading-relaxed text-ink-dim">
        No standings for this season yet. Early in a season the table fills as
        rounds are run — scrub to a completed year to see the full picture.
      </div>
    );
  }
  const max = Math.max(...rows.map((r) => parseFloat(r.points) || 0), 1);

  return (
    <div className="h-full overflow-auto">
      <table className="w-full border-collapse">
        <tbody>
          {rows.map((r) => {
            const pts = parseFloat(r.points) || 0;
            return (
              <tr key={r.pos + r.name} className="border-b border-grid/60 hover:bg-panel-2">
                <td className="relative w-9 py-2 pl-3 pr-1">
                  <span
                    className="absolute left-0 top-0 h-full w-[3px]"
                    style={{ backgroundColor: r.accent }}
                  />
                  <span className="num text-[13px] font-bold text-ink">{r.pos}</span>
                </td>
                <td className="py-2 pr-2">
                  <span className="block font-display text-[13px] font-bold leading-tight text-ink">
                    {r.name}
                  </span>
                  <span className="block truncate font-mono text-[10px] text-ink-faint">
                    {r.sub}
                  </span>
                </td>
                <td className="w-24 px-2">
                  {/* points bar */}
                  <div className="h-1 w-full bg-grid">
                    <div
                      className="h-full"
                      style={{ width: `${(pts / max) * 100}%`, backgroundColor: r.accent }}
                    />
                  </div>
                </td>
                <td className="px-2 text-right">
                  <span className="num text-[13px] font-bold text-ink">{r.points}</span>
                </td>
                <td className="w-10 px-2 pr-3 text-right">
                  <span className="num text-[11px] text-ink-faint">{r.wins}</span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
